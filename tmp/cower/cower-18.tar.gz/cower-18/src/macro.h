#ifndef MACRO_H
#define MACRO_H

#define ARRAYSIZE(x) (sizeof(x)/sizeof(x[0]))

#endif  /* MACRO_H */
